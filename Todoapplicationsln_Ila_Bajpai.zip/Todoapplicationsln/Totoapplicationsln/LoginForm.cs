﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Totoapplicationsln
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            this.cmbusername.Text = CommonDef.ADMIN_NAME;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(cmbusername.Text) && !string.IsNullOrWhiteSpace(txtpassword.Text))
            {
                switch (cmbusername.Text)
                {
                    case CommonDef.USER_NAME:
                        if (txtpassword.Text == CommonDef.USER_NAME)
                        {
                            UserPage l_objuserpage = new UserPage();
                            l_objuserpage.ShowDialog();
                           
                        }
                        else
                        {
                            MessageBox.Show("Password is not correct.");
                        }
                        break;
                    case CommonDef.ADMIN_NAME:
                        if (txtpassword.Text == CommonDef.ADMIN_NAME)
                        {
                            AdminPage l_objadminpage = new AdminPage();
                            l_objadminpage.ShowDialog();
                           
                        }
                        else
                        {
                            MessageBox.Show("Password is not correct.");
                        }
                            break;
                    default:
                        MessageBox.Show("Please enter valid username");
                        break;
                }
            }
            else
            {
                MessageBox.Show("Username or Password can't be blank.");
            }
        }
    }
}
