﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Totoapplicationsln
{

    public partial class CreateEditProject : Form
    {
        private string m_csprojectxmlfilepath = string.Empty;
        public CreateEditProject()
        {
            InitializeComponent();
            m_csprojectxmlfilepath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);

            for (int i = 0; i < 2; i++)
            {
                string[] spliarr = m_csprojectxmlfilepath.Split('\\');
                m_csprojectxmlfilepath = m_csprojectxmlfilepath.Replace("\\" + spliarr[spliarr.Count() - 1], string.Empty);
            }
            m_csprojectxmlfilepath = m_csprojectxmlfilepath + "\\DataFiles\\Project.xml";
            ReadAllExistingProject();
        }

        private void ReadAllExistingProject()
        {
            if (!string.IsNullOrEmpty(m_csprojectxmlfilepath) && File.Exists(m_csprojectxmlfilepath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csprojectxmlfilepath);
                XmlNode xmlnodeparent = xmldoc.SelectSingleNode("Projects");
                foreach (XmlNode item in xmlnodeparent.ChildNodes)
                {
                    string l_csprofilename = Convert.ToString(item.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value);
                    string l_csprofileUID = Convert.ToString(item.Attributes[CommonDef.XMLTAG_PROJECT_UID].Value);
                    AddProjectInGrid(l_csprofilename, l_csprofileUID);
                }
            }
        }

        private void btncreateproj_Click(object sender, EventArgs e)
        {
            CreateNewProject l_objcreatenewproj = new CreateNewProject(m_csprojectxmlfilepath);
            if (l_objcreatenewproj.ShowDialog() == DialogResult.OK)
            {
                AddProjectInGrid(l_objcreatenewproj.profileNameadded,l_objcreatenewproj.profileUIDadded);
            }
        }

        private void AddProjectInGrid(string f_csprofilename,string f_csprofileUid)
        {
            dgvProjectname.Rows.Add();
            int l_nrowindex = dgvProjectname.Rows.Count - 1;
            DataGridViewLinkCell l_objProfilename = (DataGridViewLinkCell)dgvProjectname.Rows[l_nrowindex].Cells[0];
            l_objProfilename.Value = f_csprofilename;
            DataGridViewTextBoxCell l_objuidadded = (DataGridViewTextBoxCell)dgvProjectname.Rows[l_nrowindex].Cells[1];
            l_objuidadded.Value = f_csprofileUid;
        }

        private void dgvProjectname_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string l_csprojectname = Convert.ToString(dgvProjectname[0, (int)e.RowIndex].Value);
            string l_csprojectUid = Convert.ToString(dgvProjectname[1, (int)e.RowIndex].Value);

            EditProject l_objeditproject = new EditProject(l_csprojectname, l_csprojectUid,m_csprojectxmlfilepath);
            l_objeditproject.ShowDialog();
        }
    }
}
