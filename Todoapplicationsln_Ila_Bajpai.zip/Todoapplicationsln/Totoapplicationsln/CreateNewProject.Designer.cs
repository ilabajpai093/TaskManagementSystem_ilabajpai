﻿namespace Totoapplicationsln
{
    partial class CreateNewProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtprojectname = new System.Windows.Forms.TextBox();
            this.btnokclick = new System.Windows.Forms.Button();
            this.btncancelClick = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(72, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Project";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Project Name";
            // 
            // txtprojectname
            // 
            this.txtprojectname.Location = new System.Drawing.Point(119, 62);
            this.txtprojectname.Name = "txtprojectname";
            this.txtprojectname.Size = new System.Drawing.Size(100, 20);
            this.txtprojectname.TabIndex = 2;
            // 
            // btnokclick
            // 
            this.btnokclick.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnokclick.Location = new System.Drawing.Point(55, 98);
            this.btnokclick.Name = "btnokclick";
            this.btnokclick.Size = new System.Drawing.Size(75, 23);
            this.btnokclick.TabIndex = 3;
            this.btnokclick.Text = "Ok";
            this.btnokclick.UseVisualStyleBackColor = true;
            this.btnokclick.Click += new System.EventHandler(this.btnokclick_Click);
            // 
            // btncancelClick
            // 
            this.btncancelClick.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btncancelClick.Location = new System.Drawing.Point(136, 98);
            this.btncancelClick.Name = "btncancelClick";
            this.btncancelClick.Size = new System.Drawing.Size(75, 23);
            this.btncancelClick.TabIndex = 4;
            this.btncancelClick.Text = "Cancel";
            this.btncancelClick.UseVisualStyleBackColor = true;
            // 
            // CreateNewProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 191);
            this.Controls.Add(this.btncancelClick);
            this.Controls.Add(this.btnokclick);
            this.Controls.Add(this.txtprojectname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateNewProject";
            this.Text = "CreateNewProject";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtprojectname;
        private System.Windows.Forms.Button btnokclick;
        private System.Windows.Forms.Button btncancelClick;

    }
}