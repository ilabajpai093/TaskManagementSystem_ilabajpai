﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Totoapplicationsln
{
    public partial class AdminPage : Form
    {
        private string m_csprojectxmlfilepath = string.Empty;
        public AdminPage()
        {
            InitializeComponent();
            m_csprojectxmlfilepath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);

            for (int i = 0; i < 2; i++)
            {
                string[] spliarr = m_csprojectxmlfilepath.Split('\\');
                m_csprojectxmlfilepath = m_csprojectxmlfilepath.Replace("\\" + spliarr[spliarr.Count() - 1], string.Empty);
            }
            m_csprojectxmlfilepath = m_csprojectxmlfilepath + "\\DataFiles\\Project.xml";
            ReadAllTasksExisting();
        }

        private void ReadAllTasksExisting()
        {
            if (!string.IsNullOrEmpty(m_csprojectxmlfilepath) && File.Exists(m_csprojectxmlfilepath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csprojectxmlfilepath);
                XmlNode xmlnodeparent = xmldoc.SelectSingleNode("Projects");
                if (xmlnodeparent != null)
                {
                    foreach (XmlNode l_Project in xmlnodeparent.ChildNodes)
                    {
                        XmlNode xmlnodetasks = l_Project.SelectSingleNode(CommonDef.XMLTAG_TASKS_MAIN);
                        if (xmlnodetasks!=null)
                        {
                            foreach (XmlNode l_Task in xmlnodetasks.ChildNodes)
                            {
                                dgvDatashow.Rows.Add();
                                int l_nrowindex = dgvDatashow.Rows.Count - 1;

                                DataGridViewTextBoxCell l_objTaskId = (DataGridViewTextBoxCell)dgvDatashow.Rows[l_nrowindex].Cells[0];
                                l_objTaskId.Value = l_Task.Attributes[CommonDef.XMLTAG_TASK_ID].Value;

                                DataGridViewTextBoxCell l_objTaskName = (DataGridViewTextBoxCell)dgvDatashow.Rows[l_nrowindex].Cells[1];
                                l_objTaskName.Value = l_Task.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value;

                                DataGridViewTextBoxCell l_objProjectName = (DataGridViewTextBoxCell)dgvDatashow.Rows[l_nrowindex].Cells[2];
                                l_objProjectName.Value = l_Project.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value;

                                DataGridViewTextBoxCell l_objTaskStatus = (DataGridViewTextBoxCell)dgvDatashow.Rows[l_nrowindex].Cells[3];
                                l_objTaskStatus.Value = Convert.ToString(l_Task.SelectSingleNode(CommonDef.XMLTAG_TASK_Status).InnerText);

                                DataGridViewTextBoxCell l_objTaskAssignee = (DataGridViewTextBoxCell)dgvDatashow.Rows[l_nrowindex].Cells[4];
                                string l_csDevempIdName = Convert.ToString(l_Task.SelectSingleNode(CommonDef.XMLTAG_DEVELOPER_TAG).InnerText);
                                string[] splitArr = l_csDevempIdName.Split('$');
                                l_objTaskAssignee.Value = splitArr[1];
                            } 
                        }
                    }
                }
            }
        }

        private void createNewProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateEditProject l_objcreateeditproj = new CreateEditProject();
            l_objcreateeditproj.ShowDialog();
        }

        
        
    }
}
