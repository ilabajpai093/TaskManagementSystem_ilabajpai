﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Totoapplicationsln
{
    public partial class EditProject : Form
    {
        string m_csProjectUid = string.Empty;
        string m_csFilePath = string.Empty;
        public EditProject(string f_csProjectName,string f_csProjectUid,string f_csProjectxmlFilepath)
        {
            InitializeComponent();
            lblCurrentProject.Text = f_csProjectName;
            m_csProjectUid = f_csProjectUid;
            m_csFilePath = f_csProjectxmlFilepath;
            ReadAllExistingTask();
        }

        private void ReadAllExistingTask()
        {
            if (!string.IsNullOrEmpty(m_csFilePath) && File.Exists(m_csFilePath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csFilePath);
                XmlNode xmlProjectnode = xmldoc.SelectSingleNode("//Projects//Project[@UID='" + m_csProjectUid + "']");
                if (xmlProjectnode != null)
                {
                    XmlNode xmlTasksnode = xmlProjectnode.SelectSingleNode("//Projects//Project[@UID='" + m_csProjectUid + "']//" + CommonDef.XMLTAG_TASKS_MAIN);
                    if (xmlTasksnode != null)
                    {
                        foreach (XmlNode item in xmlTasksnode.ChildNodes)
                        {
                            string l_csTaskname = Convert.ToString(item.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value);
                            string l_csTaskUID = Convert.ToString(item.Attributes[CommonDef.XMLTAG_TASK_ID].Value);
                            AddTaskInGrid(l_csTaskname, l_csTaskUID);
                        }
                    }
                }
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab.Text == "Project")
            {
                txteditname.Text = lblCurrentProject.Text;
            }
        }

        private void btnEditProjectName_Click(object sender, EventArgs e)
        {
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(m_csFilePath);
            XmlNode xmlProjectnode = xmldoc.SelectSingleNode("//Projects//Project[@UID='" + m_csProjectUid + "']");
            if (xmlProjectnode != null)
            {
                xmlProjectnode.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value = txteditname.Text;
            }
            else
            {
                MessageBox.Show("The Project doesn't exists to edit");
            }
            xmldoc.Save(m_csFilePath);
            lblCurrentProject.Text = txteditname.Text;
        }

        private void btnAddDeveloper_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(m_csFilePath) && File.Exists(m_csFilePath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csFilePath);
                //XmlNode xmlnodeparent = xmldoc.SelectSingleNode("//Projects");
                XmlNode xmlProjectnode = xmldoc.SelectSingleNode("//Projects//Project[@UID='" + m_csProjectUid + "']");
                if (xmlProjectnode != null)
                {
                    XmlNode xmlDevelopersnode = xmlProjectnode.SelectSingleNode("//Projects//Project[@UID='" + m_csProjectUid + "']//" + CommonDef.XMLTAG_DEVELOPERS_MAIN);
                    if (xmlDevelopersnode == null)
                    {
                        XmlElement xDevlopersElement = xmldoc.CreateElement(CommonDef.XMLTAG_DEVELOPERS_MAIN);
                        xmlProjectnode.AppendChild(xDevlopersElement);
                    }
                    xmlDevelopersnode = xmlProjectnode.SelectSingleNode("//Projects//Project[@UID='" + m_csProjectUid + "']//" + CommonDef.XMLTAG_DEVELOPERS_MAIN);
                    XmlNode xmldevExisting = xmlDevelopersnode.SelectSingleNode(CommonDef.XMLTAG_DEVELOPER_TAG + "[@" + CommonDef.XMLTAG_DEVELOPER_EMPID + "='" + txtEmpId.Text + "']");
                    if (xmldevExisting == null)
                    {
                        XmlElement xmlDevelopernode = xmldoc.CreateElement(CommonDef.XMLTAG_DEVELOPER_TAG);
                        XmlAttribute xmlattrempid = xmldoc.CreateAttribute(CommonDef.XMLTAG_DEVELOPER_EMPID);
                        xmlattrempid.Value = txtEmpId.Text;
                        XmlAttribute xmlattrEmpName = xmldoc.CreateAttribute(CommonDef.XMLTAG_PROJECT_NAME);
                        xmlattrEmpName.Value = txtEmpName.Text;
                        xmlDevelopernode.Attributes.Append(xmlattrempid);
                        xmlDevelopernode.Attributes.Append(xmlattrEmpName);
                        xmlDevelopersnode.AppendChild(xmlDevelopernode);
                    }
                    else
                    {
                        MessageBox.Show("Employee with same Employee Id already exists.");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("The Project doesn't exists");
                    return;
                }

                xmldoc.Save(m_csFilePath);
                MessageBox.Show("Developer added successfully!!!");
            }
        }

        private void AddTaskInGrid(string f_csprofilename, string f_csprofileUid)
        {
            dgvTaskProfile.Rows.Add();
            int l_nrowindex = dgvTaskProfile.Rows.Count - 1;
            DataGridViewTextBoxCell l_objProfilename = (DataGridViewTextBoxCell)dgvTaskProfile.Rows[l_nrowindex].Cells[1];
            l_objProfilename.Value = f_csprofilename;
            DataGridViewLinkCell l_objuidadded = (DataGridViewLinkCell)dgvTaskProfile.Rows[l_nrowindex].Cells[0];
            l_objuidadded.Value = f_csprofileUid;
        }

        private void btnCreateTask_Click(object sender, EventArgs e)
        {
            TaskEditCreateForm l_objtaskeditcreateform = new TaskEditCreateForm(m_csFilePath, "Create", m_csProjectUid);
            if (l_objtaskeditcreateform.ShowDialog() == DialogResult.OK)
            {
                AddTaskInGrid(l_objtaskeditcreateform.TaskName, l_objtaskeditcreateform.TaskUid);
            }
        }

        private void dgvTaskProfile_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                string l_csTaskname = Convert.ToString(dgvTaskProfile[1, (int)e.RowIndex].Value);
                string l_csTaskUid = Convert.ToString(dgvTaskProfile[0, (int)e.RowIndex].Value);
                TaskEditCreateForm l_objtaskeditcreateform = new TaskEditCreateForm(m_csFilePath, "Edit", m_csProjectUid, l_csTaskUid);
                if (l_objtaskeditcreateform.ShowDialog() == DialogResult.OK)
                {
                    foreach (DataGridViewRow row in dgvTaskProfile.Rows)
                    {
                        if (Convert.ToString(row.Cells[0].Value) == l_csTaskUid)
                        {
                            row.Cells[1].Value = l_objtaskeditcreateform.TaskName;
                        }
                    }
                }
            }
        }
    }
}
