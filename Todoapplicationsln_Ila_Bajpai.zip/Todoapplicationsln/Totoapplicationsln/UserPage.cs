﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Totoapplicationsln
{
    public partial class UserPage : Form
    {
        private string m_csprojectxmlfilepath = string.Empty;
        public UserPage()
        {
            InitializeComponent();
            m_csprojectxmlfilepath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);

            for (int i = 0; i < 2; i++)
            {
                string[] spliarr = m_csprojectxmlfilepath.Split('\\');
                m_csprojectxmlfilepath = m_csprojectxmlfilepath.Replace("\\" + spliarr[spliarr.Count() - 1], string.Empty);
            }

            m_csprojectxmlfilepath = m_csprojectxmlfilepath + "\\DataFiles\\Project.xml";
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            dgvTaskList.Rows.Clear();
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(m_csprojectxmlfilepath);
            XmlNode xmlnodeparent = xmldoc.SelectSingleNode("Projects");
            if (xmlnodeparent != null)
            {
                foreach (XmlNode l_Project in xmlnodeparent.ChildNodes)
                {
                    XmlNode xmlnodetasks = l_Project.SelectSingleNode(CommonDef.XMLTAG_TASKS_MAIN);
                    if (xmlnodetasks != null)
                    {
                        foreach (XmlNode l_Task in xmlnodetasks.ChildNodes)
                        {
                            string l_csDevempIdName = Convert.ToString(l_Task.SelectSingleNode(CommonDef.XMLTAG_DEVELOPER_TAG).InnerText);
                                string[] splitArr = l_csDevempIdName.Split('$');
                                if (splitArr[0] == txtEmpId.Text)
                                {
                                    dgvTaskList.Rows.Add();
                                    int l_nrowindex = dgvTaskList.Rows.Count - 1;
                                    DataGridViewLinkCell l_objuidadded = (DataGridViewLinkCell)dgvTaskList.Rows[l_nrowindex].Cells[0];
                                    l_objuidadded.Value = l_Task.Attributes[CommonDef.XMLTAG_TASK_ID].Value;

                                    DataGridViewTextBoxCell l_objTaskName = (DataGridViewTextBoxCell)dgvTaskList.Rows[l_nrowindex].Cells[1];
                                    l_objTaskName.Value = l_Task.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value;

                                    DataGridViewTextBoxCell l_objProjectName = (DataGridViewTextBoxCell)dgvTaskList.Rows[l_nrowindex].Cells[2];
                                    l_objProjectName.Value = l_Project.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value;

                                    DataGridViewTextBoxCell l_objProjectId = (DataGridViewTextBoxCell)dgvTaskList.Rows[l_nrowindex].Cells[3];
                                    l_objProjectId.Value = l_Project.Attributes[CommonDef.XMLTAG_PROJECT_UID].Value;
                                }
                        }
                    }
                }
            }

        }

        private void dgvTaskList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                string l_csTaskname = Convert.ToString(dgvTaskList[1, (int)e.RowIndex].Value);
                string l_csTaskUid = Convert.ToString(dgvTaskList[0, (int)e.RowIndex].Value);
                string l_csProjectUid = Convert.ToString(dgvTaskList[3, (int)e.RowIndex].Value);
                TaskEditCreateForm l_objtaskeditcreateform = new TaskEditCreateForm(m_csprojectxmlfilepath, "User", l_csProjectUid, l_csTaskUid);
                l_objtaskeditcreateform.ShowDialog();
            }
        }
    }
}
