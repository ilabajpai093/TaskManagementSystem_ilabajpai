﻿namespace Totoapplicationsln
{
    partial class EditProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvTaskProfile = new System.Windows.Forms.DataGridView();
            this.dgvTaskid = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dgvTaskName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCreateTask = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnAddDeveloper = new System.Windows.Forms.Button();
            this.txtEmpName = new System.Windows.Forms.TextBox();
            this.txtEmpId = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnEditProjectName = new System.Windows.Forms.Button();
            this.txteditname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCurrentProject = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTaskProfile)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.Location = new System.Drawing.Point(0, 48);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(740, 361);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.btnCreateTask);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(732, 335);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tasks";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvTaskProfile);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 59);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(726, 273);
            this.panel1.TabIndex = 1;
            // 
            // dgvTaskProfile
            // 
            this.dgvTaskProfile.AllowUserToAddRows = false;
            this.dgvTaskProfile.AllowUserToDeleteRows = false;
            this.dgvTaskProfile.AllowUserToResizeColumns = false;
            this.dgvTaskProfile.AllowUserToResizeRows = false;
            this.dgvTaskProfile.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTaskProfile.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvTaskid,
            this.dgvTaskName});
            this.dgvTaskProfile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTaskProfile.Location = new System.Drawing.Point(0, 0);
            this.dgvTaskProfile.MultiSelect = false;
            this.dgvTaskProfile.Name = "dgvTaskProfile";
            this.dgvTaskProfile.RowHeadersVisible = false;
            this.dgvTaskProfile.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTaskProfile.Size = new System.Drawing.Size(726, 273);
            this.dgvTaskProfile.TabIndex = 0;
            this.dgvTaskProfile.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTaskProfile_CellContentClick);
            // 
            // dgvTaskid
            // 
            this.dgvTaskid.HeaderText = "Task Id";
            this.dgvTaskid.Name = "dgvTaskid";
            // 
            // dgvTaskName
            // 
            this.dgvTaskName.HeaderText = "Task Name";
            this.dgvTaskName.Name = "dgvTaskName";
            this.dgvTaskName.ReadOnly = true;
            // 
            // btnCreateTask
            // 
            this.btnCreateTask.Location = new System.Drawing.Point(8, 6);
            this.btnCreateTask.Name = "btnCreateTask";
            this.btnCreateTask.Size = new System.Drawing.Size(126, 23);
            this.btnCreateTask.TabIndex = 0;
            this.btnCreateTask.Text = "Create Task/ToDo";
            this.btnCreateTask.UseVisualStyleBackColor = true;
            this.btnCreateTask.Click += new System.EventHandler(this.btnCreateTask_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnAddDeveloper);
            this.tabPage2.Controls.Add(this.txtEmpName);
            this.tabPage2.Controls.Add(this.txtEmpId);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(732, 335);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Developers";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnAddDeveloper
            // 
            this.btnAddDeveloper.Location = new System.Drawing.Point(289, 147);
            this.btnAddDeveloper.Name = "btnAddDeveloper";
            this.btnAddDeveloper.Size = new System.Drawing.Size(100, 23);
            this.btnAddDeveloper.TabIndex = 5;
            this.btnAddDeveloper.Text = "Add Developer";
            this.btnAddDeveloper.UseVisualStyleBackColor = true;
            this.btnAddDeveloper.Click += new System.EventHandler(this.btnAddDeveloper_Click);
            // 
            // txtEmpName
            // 
            this.txtEmpName.Location = new System.Drawing.Point(289, 110);
            this.txtEmpName.Name = "txtEmpName";
            this.txtEmpName.Size = new System.Drawing.Size(100, 20);
            this.txtEmpName.TabIndex = 4;
            // 
            // txtEmpId
            // 
            this.txtEmpId.Location = new System.Drawing.Point(289, 71);
            this.txtEmpId.Name = "txtEmpId";
            this.txtEmpId.Size = new System.Drawing.Size(100, 20);
            this.txtEmpId.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(224, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Emp Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(234, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Emp Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(183, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(326, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "Add Developers to current Project";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnEditProjectName);
            this.tabPage3.Controls.Add(this.txteditname);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(732, 335);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Project";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnEditProjectName
            // 
            this.btnEditProjectName.Location = new System.Drawing.Point(151, 112);
            this.btnEditProjectName.Name = "btnEditProjectName";
            this.btnEditProjectName.Size = new System.Drawing.Size(75, 23);
            this.btnEditProjectName.TabIndex = 3;
            this.btnEditProjectName.Text = "Edit";
            this.btnEditProjectName.UseVisualStyleBackColor = true;
            this.btnEditProjectName.Click += new System.EventHandler(this.btnEditProjectName_Click);
            // 
            // txteditname
            // 
            this.txteditname.Location = new System.Drawing.Point(151, 68);
            this.txteditname.Name = "txteditname";
            this.txteditname.Size = new System.Drawing.Size(100, 20);
            this.txteditname.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Project Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(276, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Edit Project Name";
            // 
            // lblCurrentProject
            // 
            this.lblCurrentProject.AutoSize = true;
            this.lblCurrentProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentProject.Location = new System.Drawing.Point(12, 9);
            this.lblCurrentProject.Name = "lblCurrentProject";
            this.lblCurrentProject.Size = new System.Drawing.Size(70, 25);
            this.lblCurrentProject.TabIndex = 1;
            this.lblCurrentProject.Text = "label1";
            // 
            // EditProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 409);
            this.Controls.Add(this.lblCurrentProject);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditProject";
            this.Text = "EditProject";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTaskProfile)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblCurrentProject;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txteditname;
        private System.Windows.Forms.Button btnEditProjectName;
        private System.Windows.Forms.Button btnAddDeveloper;
        private System.Windows.Forms.TextBox txtEmpName;
        private System.Windows.Forms.TextBox txtEmpId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCreateTask;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvTaskProfile;
        private System.Windows.Forms.DataGridViewLinkColumn dgvTaskid;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvTaskName;

    }
}