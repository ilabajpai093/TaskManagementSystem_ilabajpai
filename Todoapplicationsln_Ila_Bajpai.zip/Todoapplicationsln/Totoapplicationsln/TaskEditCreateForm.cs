﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Totoapplicationsln
{
    public partial class TaskEditCreateForm : Form
    {
        private string m_csProjectxmlFilepath = string.Empty;
        private string m_csprojectUid = string.Empty;
        private string m_csTaskUid = string.Empty;
        private string m_csTaskName = string.Empty;

        public string TaskName
        {
            get { return m_csTaskName; }
            set { m_csTaskName = value; }
        }

        public string TaskUid
        {
            get { return m_csTaskUid; }
            set { m_csTaskUid = value; }
        }
        public TaskEditCreateForm(string f_csProjectxmlfile,string f_csActiontaken,string f_csProjectUid,string f_cstaskId="")
        {
            InitializeComponent();
            m_csProjectxmlFilepath = f_csProjectxmlfile;
            m_csprojectUid = f_csProjectUid;
            LoadExistingDevelopers();
            TaskUid = f_cstaskId;
            if (f_csActiontaken == "Edit")
            {
                ReadAllDataandDisplay("Edit");
            }
            else if (f_csActiontaken == "User")
            {
                ReadAllDataandDisplay("User");
            }
        }

        private void ReadAllDataandDisplay(string f_csActiontaken)
        {
            if (!string.IsNullOrEmpty(m_csProjectxmlFilepath) && File.Exists(m_csProjectxmlFilepath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csProjectxmlFilepath);
                XmlNode xmlProjectnode = xmldoc.SelectSingleNode("//Projects//Project[@UID='" + m_csprojectUid + "']");
                if (xmlProjectnode != null)
                {
                    XmlNode xmlTasksnode = xmlProjectnode.SelectSingleNode(CommonDef.XMLTAG_TASKS_MAIN);
                    if (xmlTasksnode != null)
                    {
                        XmlNode xmlTaskExisting = xmlTasksnode.SelectSingleNode(CommonDef.XMLTAG_TASK_TAG + "[@" + CommonDef.XMLTAG_TASK_ID + "='" + TaskUid + "']");
                        if (xmlTaskExisting != null)
                        {
                            txtTaskid.Text = Convert.ToString(xmlTaskExisting.Attributes[CommonDef.XMLTAG_TASK_ID].Value);
                            txttaskname.Text = Convert.ToString(xmlTaskExisting.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value);
                            cmbTaskTracker.Text = Convert.ToString(xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_TRACKER).InnerText);
                            cmbStatus.Text = Convert.ToString(xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_Status).InnerText);
                            cmbDevelopers.Text = Convert.ToString((xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_DEVELOPER_TAG).InnerText).Split('$').Last());
                            cmbPriority.Text = Convert.ToString(xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_PRIORITY).InnerText);
                            dateTimePickerStartDate.Value = Convert.ToDateTime(xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_START_DATE).InnerText);
                            dateTimePickerEndDate.Value = Convert.ToDateTime(xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_END_DATE).InnerText);
                            txtdescription.Text = Convert.ToString(xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_DESCRIPTION).InnerText);
                            if (f_csActiontaken == "Edit")
                            {
                                txtTaskid.ReadOnly = true;
                                btnCreateTask.Text = "Edit Task";
                            }
                            else
                            {
                                txtTaskid.ReadOnly = true;
                                txttaskname.ReadOnly = true;
                                cmbTaskTracker.Enabled = false;
                                cmbDevelopers.Enabled = false;
                                cmbPriority.Enabled = false;
                                dateTimePickerStartDate.Enabled = false;
                                dateTimePickerEndDate.Enabled = false;
                                txtdescription.ReadOnly = true;
                                btnCreateTask.Text = "Edit Task";
                            }
                        }
                    }
                }
            }
        }

        private void LoadExistingDevelopers()
        {
            if (!string.IsNullOrEmpty(m_csProjectxmlFilepath) && File.Exists(m_csProjectxmlFilepath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csProjectxmlFilepath);
                XmlNode xmlProjectnode = xmldoc.SelectSingleNode("//Projects//Project[@UID='" + m_csprojectUid + "']");
                if (xmlProjectnode != null)
                {
                    XmlNode xmlDevelopersnode = xmlProjectnode.SelectSingleNode("//Projects//Project[@UID='" + m_csprojectUid + "']//" + CommonDef.XMLTAG_DEVELOPERS_MAIN);
                   // List<string> l_csListDevelopersname = new List<string>();
                    Dictionary<string, string> l_csListDevelopersname = new Dictionary<string, string>();
                    if (xmlDevelopersnode!=null)
                    {
                        foreach (XmlNode item in xmlDevelopersnode.ChildNodes)
                        {
                            if (!l_csListDevelopersname.Keys.Contains(Convert.ToString(item.Attributes[CommonDef.XMLTAG_DEVELOPER_EMPID].Value)))
                            {
                                l_csListDevelopersname.Add(Convert.ToString(item.Attributes[CommonDef.XMLTAG_DEVELOPER_EMPID].Value), Convert.ToString(item.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value));
                            }
                        }
                    }

                    if (l_csListDevelopersname != null && l_csListDevelopersname.Count > 0)
                    {
                        cmbDevelopers.DataSource = new BindingSource(l_csListDevelopersname, null);
                        cmbDevelopers.DisplayMember = "Value";
                        cmbDevelopers.ValueMember = "Key";
                        cmbDevelopers.Text = l_csListDevelopersname.Values.ElementAt(0);
                    }
                }
            }
        }

        private void btnCreateTask_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(m_csProjectxmlFilepath) && File.Exists(m_csProjectxmlFilepath))
            {
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(m_csProjectxmlFilepath);
                XmlNode xmlProjectnode = xmldoc.SelectSingleNode("//Projects//Project[@UID='" + m_csprojectUid + "']");
                 if (xmlProjectnode != null)
                 {
                     XmlNode xmlTasksnode = xmlProjectnode.SelectSingleNode(CommonDef.XMLTAG_TASKS_MAIN);
                     if (xmlTasksnode == null)
                     {
                         XmlElement xTasksElement = xmldoc.CreateElement(CommonDef.XMLTAG_TASKS_MAIN);
                         xmlProjectnode.AppendChild(xTasksElement);
                     }
                     xmlTasksnode = xmlProjectnode.SelectSingleNode(CommonDef.XMLTAG_TASKS_MAIN);
                     XmlNode xmlTaskExisting = xmlTasksnode.SelectSingleNode(CommonDef.XMLTAG_TASK_TAG + "[@" + CommonDef.XMLTAG_TASK_ID + "='" + txtTaskid.Text + "']");
                     if (btnCreateTask.Text == "Create Task")
                     {
                         if (xmlTaskExisting == null)
                         {
                             XmlElement xmlTasknode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_TAG);
                             XmlAttribute xmlattrTaskid = xmldoc.CreateAttribute(CommonDef.XMLTAG_TASK_ID);
                             xmlattrTaskid.Value = "#"+txtTaskid.Text;
                             TaskUid = "#" + txtTaskid.Text;
                             XmlAttribute xmlattrTaskName = xmldoc.CreateAttribute(CommonDef.XMLTAG_PROJECT_NAME);
                             xmlattrTaskName.Value = txttaskname.Text;
                             TaskName = txttaskname.Text;
                             xmlTasknode.Attributes.Append(xmlattrTaskid);
                             xmlTasknode.Attributes.Append(xmlattrTaskName);
                             xmlTasksnode.AppendChild(xmlTasknode);

                             XmlElement xmlTaskTrackernode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_TRACKER);
                             xmlTaskTrackernode.InnerText = Convert.ToString(cmbTaskTracker.Text);
                             xmlTasknode.AppendChild(xmlTaskTrackernode);

                             XmlElement xmlTaskStatusnode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_Status);
                             xmlTaskStatusnode.InnerText = Convert.ToString(cmbStatus.Text);
                             xmlTasknode.AppendChild(xmlTaskStatusnode);

                             XmlElement xmlTaskDevelopernode = xmldoc.CreateElement(CommonDef.XMLTAG_DEVELOPER_TAG);
                             string cmbvalue = Convert.ToString(cmbDevelopers.SelectedValue);
                             string cmbtext = Convert.ToString(cmbDevelopers.Text);
                             xmlTaskDevelopernode.InnerText = cmbvalue + "$" + cmbtext;
                             xmlTasknode.AppendChild(xmlTaskDevelopernode);

                             XmlElement xmlTaskPrioritynode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_PRIORITY);
                             xmlTaskPrioritynode.InnerText = Convert.ToString(cmbPriority.Text);
                             xmlTasknode.AppendChild(xmlTaskPrioritynode);

                             XmlElement xmlTaskStartDatenode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_START_DATE);
                             xmlTaskStartDatenode.InnerText = Convert.ToString(dateTimePickerStartDate.Value);
                             xmlTasknode.AppendChild(xmlTaskStartDatenode);

                             XmlElement xmlTaskEndDatenode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_END_DATE);
                             xmlTaskEndDatenode.InnerText = Convert.ToString(dateTimePickerEndDate.Value);
                             xmlTasknode.AppendChild(xmlTaskEndDatenode);

                             XmlElement xmlTaskDescriptionnode = xmldoc.CreateElement(CommonDef.XMLTAG_TASK_DESCRIPTION);
                             xmlTaskDescriptionnode.InnerText = Convert.ToString(txtdescription.Text);
                             xmlTasknode.AppendChild(xmlTaskDescriptionnode);
                         }
                         else
                         {
                             MessageBox.Show("Task with same Id already exists.");
                         }
                     }
                     else
                     {
                         if (xmlTaskExisting != null)
                         {
                             xmlTaskExisting.Attributes[CommonDef.XMLTAG_PROJECT_NAME].Value = txttaskname.Text;
                             TaskName = txttaskname.Text;
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_TRACKER).InnerText = Convert.ToString(cmbTaskTracker.Text);
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_Status).InnerText = Convert.ToString(cmbStatus.Text);
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_DEVELOPER_TAG).InnerText = Convert.ToString(cmbDevelopers.SelectedValue)+"$"+cmbDevelopers.Text;
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_PRIORITY).InnerText = Convert.ToString(cmbPriority.Text);
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_START_DATE).InnerText = Convert.ToString(dateTimePickerStartDate.Value);
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_END_DATE).InnerText = Convert.ToString(dateTimePickerEndDate.Value);
                             xmlTaskExisting.SelectSingleNode(CommonDef.XMLTAG_TASK_DESCRIPTION).InnerText = Convert.ToString(txtdescription.Text);
                         }
                         else
                         {
                             MessageBox.Show("Task to be edited doesn't exists.");
                         }
                     }
                 }
               
                xmldoc.Save(m_csProjectxmlFilepath);
            }
        }
    }
}
