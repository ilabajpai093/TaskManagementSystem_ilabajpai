﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Totoapplicationsln
{
    class CommonDef
    {
        public const string USER_NAME = "User";

        public const string ADMIN_NAME = "Admin";

        public const string XMLTAG_PROJECT = "Project";

        public const string XMLTAG_PROJECT_NAME = "Name";

        public const string XMLTAG_PROJECT_UID = "UID";

        public const string XMLTAG_DEVELOPERS_MAIN = "Developers";

        public const string XMLTAG_DEVELOPER_TAG = "Developer";

        public const string XMLTAG_DEVELOPER_EMPID = "Emp_ID";

        public const string XMLTAG_TASKS_MAIN = "Tasks";

        public const string XMLTAG_TASK_TAG = "Task";

        public const string XMLTAG_TASK_ID = "ID";

        public const string XMLTAG_TASK_TRACKER = "Tracker";

        public const string XMLTAG_TASK_Status = "Status";

        public const string XMLTAG_TASK_PRIORITY = "Priority";

        public const string XMLTAG_TASK_START_DATE = "Start_Date";

        public const string XMLTAG_TASK_END_DATE = "End_Date";

        public const string XMLTAG_TASK_DESCRIPTION = "Description";
    }
}
