﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Totoapplicationsln
{
    public partial class CreateNewProject : Form
    {
        private string m_csprojectxmlfilepath = string.Empty;
        private string m_csprofileNameadded = string.Empty;
        private string m_csprofileUIDadded = string.Empty;

        public string profileUIDadded
        {
            get { return m_csprofileUIDadded; }
            set { m_csprofileUIDadded = value; }
        }

        public string profileNameadded
        {
            get { return m_csprofileNameadded; }
            set { m_csprofileNameadded = value; }
        }
        public CreateNewProject(string f_csxmlfilepath)
        {
            InitializeComponent();
            m_csprojectxmlfilepath = f_csxmlfilepath;
        }

        private void btnokclick_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtprojectname.Text))
                {
                    if (!string.IsNullOrEmpty(m_csprojectxmlfilepath) && File.Exists(m_csprojectxmlfilepath))
                    {
                        XmlDocument xmldoc = new XmlDocument();
                        xmldoc.Load(m_csprojectxmlfilepath);
                        XmlNode xmlnodeparent = xmldoc.SelectSingleNode("//Projects");
                        XmlElement xprojectnode = xmldoc.CreateElement(CommonDef.XMLTAG_PROJECT);
                        XmlAttribute xmlProjName = xmldoc.CreateAttribute(CommonDef.XMLTAG_PROJECT_NAME);
                        xmlProjName.Value = txtprojectname.Text;
                        XmlAttribute xmlProjUID = xmldoc.CreateAttribute(CommonDef.XMLTAG_PROJECT_UID);
                        xmlProjUID.Value = Convert.ToString(Guid.NewGuid());
                        profileUIDadded = xmlProjUID.Value;
                        xprojectnode.Attributes.Append(xmlProjName);
                        xprojectnode.Attributes.Append(xmlProjUID);
                        xmlnodeparent.AppendChild(xprojectnode);
                        xmldoc.Save(m_csprojectxmlfilepath);
                        profileNameadded = txtprojectname.Text;
                    }
                }
            }
            catch (Exception)
            {
                //throw;
            }
        }
    }
}
