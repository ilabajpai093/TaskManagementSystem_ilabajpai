﻿namespace Totoapplicationsln
{
    partial class CreateEditProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvProjectname = new System.Windows.Forms.DataGridView();
            this.dgvprofilenamelink = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dgvUidprojectname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btncreateproj = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjectname)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvProjectname
            // 
            this.dgvProjectname.AllowUserToAddRows = false;
            this.dgvProjectname.AllowUserToResizeColumns = false;
            this.dgvProjectname.AllowUserToResizeRows = false;
            this.dgvProjectname.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dgvProjectname.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjectname.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvprofilenamelink,
            this.dgvUidprojectname});
            this.dgvProjectname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProjectname.Location = new System.Drawing.Point(0, 0);
            this.dgvProjectname.MultiSelect = false;
            this.dgvProjectname.Name = "dgvProjectname";
            this.dgvProjectname.RowHeadersVisible = false;
            this.dgvProjectname.Size = new System.Drawing.Size(637, 313);
            this.dgvProjectname.TabIndex = 0;
            this.dgvProjectname.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProjectname_CellContentClick);
            // 
            // dgvprofilenamelink
            // 
            this.dgvprofilenamelink.HeaderText = "ProjectName";
            this.dgvprofilenamelink.Name = "dgvprofilenamelink";
            // 
            // dgvUidprojectname
            // 
            this.dgvUidprojectname.HeaderText = "UIDProject";
            this.dgvUidprojectname.Name = "dgvUidprojectname";
            this.dgvUidprojectname.ReadOnly = true;
            this.dgvUidprojectname.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvProjectname);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 105);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(637, 313);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(179, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Click on the link to edit project";
            // 
            // btncreateproj
            // 
            this.btncreateproj.Location = new System.Drawing.Point(12, 12);
            this.btncreateproj.Name = "btncreateproj";
            this.btncreateproj.Size = new System.Drawing.Size(113, 23);
            this.btncreateproj.TabIndex = 2;
            this.btncreateproj.Text = "Create New Project";
            this.btncreateproj.UseVisualStyleBackColor = true;
            this.btncreateproj.Click += new System.EventHandler(this.btncreateproj_Click);
            // 
            // CreateEditProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 418);
            this.Controls.Add(this.btncreateproj);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateEditProject";
            this.Text = "CreateEditProject";
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjectname)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvProjectname;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewLinkColumn dgvprofilenamelink;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvUidprojectname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btncreateproj;
    }
}